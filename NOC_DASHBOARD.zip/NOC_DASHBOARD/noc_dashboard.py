"""
=============================================================================
 NetSupervision — NOC Dashboard
 Tableau de bord réseau en temps réel
 Technologies : Python · Tkinter · MySQL · POO · matplotlib
=============================================================================

ARCHITECTURE (POO) :
  DatabaseManager    → gère la connexion et les requêtes MySQL
  Packet             → modèle de données d'un paquet réseau
  NetworkSimulator   → simule/génère des données réseau (remplace Wireshark)
  KPICard            → widget Tkinter pour une carte de métrique (ex: 18 432 paquets)
  TrafficChart       → graphique de trafic (ligne) avec matplotlib
  ProtocolChart      → graphique camembert des protocoles
  TopSourcesTable    → tableau des IP sources les plus actives
  VolumeChart        → histogramme du volume / 5 min
  AlertBadge         → indicateur d'alertes actives
  NOCDashboard       → fenêtre principale — orchestre tous les composants

PRÉREQUIS :
  pip install mysql-connector-python matplotlib

CONFIGURATION MySQL :
  Créez la base de données en lançant : python noc_dashboard.py --init-db
  Ou exécutez manuellement le bloc SQL dans init_database().
=============================================================================
"""

import tkinter as tk
from tkinter import ttk, messagebox
import threading
import time
import random
import math
from datetime import datetime, timedelta
from collections import defaultdict, deque
import argparse
import sys

# ── Bibliothèques optionnelles ───────────────────────────────────────────────
try:
    import mysql.connector
    from mysql.connector import Error as MySQLError
    MYSQL_AVAILABLE = True
except ImportError:
    MYSQL_AVAILABLE = False
    print("[AVERTISSEMENT] mysql-connector-python non installé.")
    print("  → pip install mysql-connector-python")
    print("  → Mode démo sans base de données activé.\n")

try:
    import matplotlib
    matplotlib.use("TkAgg")                          # backend compatible Tkinter
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    import matplotlib.pyplot as plt
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False
    print("[AVERTISSEMENT] matplotlib non installé.")
    print("  → pip install matplotlib\n")


# ─────────────────────────────────────────────────────────────────────────────
#  PALETTE DE COULEURS  (thème dark NOC)
# ─────────────────────────────────────────────────────────────────────────────
COLORS = {
    "bg_dark":      "#0d1117",   # fond général très sombre
    "bg_card":      "#161b22",   # fond des cartes
    "bg_chart":     "#0d1117",   # fond des graphiques
    "border":       "#21262d",   # bords subtils
    "accent_green": "#39d353",   # vert vif (trafic, positif)
    "accent_cyan":  "#00b4d8",   # cyan (TCP)
    "accent_blue":  "#1f6feb",   # bleu
    "text_primary": "#e6edf3",   # texte principal blanc cassé
    "text_muted":   "#7d8590",   # texte secondaire gris
    "text_green":   "#3fb950",   # valeur positive
    "text_red":     "#f85149",   # valeur négative / alerte
    "text_orange":  "#d29922",   # avertissement
    "protocol_tcp": "#00b4d8",
    "protocol_udp": "#3fb950",
    "protocol_http":"#8957e5",
    "protocol_dns": "#d29922",
    "protocol_arp": "#6e7681",
}


# ─────────────────────────────────────────────────────────────────────────────
#  MODÈLE DE DONNÉES : Packet
# ─────────────────────────────────────────────────────────────────────────────
class Packet:
    """
    Représente un paquet réseau capturé.
    C'est le modèle central qui circule entre les couches (DB ↔ UI).
    """
    # Protocoles possibles avec leur poids de probabilité
    PROTOCOLS = ["TCP", "UDP", "HTTP", "DNS", "ARP"]
    WEIGHTS   = [0.58, 0.22, 0.11, 0.06, 0.03]

    def __init__(self, src_ip: str, dst_ip: str, protocol: str,
                 size: int, timestamp: datetime | None = None):
        self.src_ip    = src_ip
        self.dst_ip    = dst_ip
        self.protocol  = protocol
        self.size      = size                          # octets
        self.timestamp = timestamp or datetime.now()

    @classmethod
    def random(cls) -> "Packet":
        """Génère un paquet aléatoire pour la simulation."""
        subnets = ["192.168.1", "10.0.0", "172.16.0"]
        src  = f"{random.choice(subnets)}.{random.randint(1, 254)}"
        dst  = f"10.0.{random.randint(0,3)}.{random.randint(1,254)}"
        proto = random.choices(cls.PROTOCOLS, weights=cls.WEIGHTS, k=1)[0]
        size  = random.randint(64, 1500)
        return cls(src, dst, proto, size)

    def to_tuple(self) -> tuple:
        """Sérialisation pour l'insertion MySQL."""
        return (self.src_ip, self.dst_ip, self.protocol,
                self.size, self.timestamp.strftime("%Y-%m-%d %H:%M:%S"))


# ─────────────────────────────────────────────────────────────────────────────
#  COUCHE BASE DE DONNÉES : DatabaseManager
# ─────────────────────────────────────────────────────────────────────────────
class DatabaseManager:
    """
    Gère toute l'interaction avec MySQL :
      - connexion / déconnexion
      - création des tables (init)
      - insertion de paquets
      - requêtes d'agrégation pour les KPI

    Usage :
        db = DatabaseManager(host="localhost", user="root", password="xxx", database="noc_db")
        db.connect()
        db.insert_packet(packet)
        stats = db.get_stats()
        db.disconnect()
    """

    # ── Schéma SQL ────────────────────────────────────────────────────────────
    CREATE_DB_SQL = "CREATE DATABASE IF NOT EXISTS {db} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

    CREATE_TABLE_PACKETS = """
        CREATE TABLE IF NOT EXISTS packets (
            id          INT AUTO_INCREMENT PRIMARY KEY,
            src_ip      VARCHAR(45)  NOT NULL,          -- IPv4 ou IPv6
            dst_ip      VARCHAR(45)  NOT NULL,
            protocol    VARCHAR(10)  NOT NULL,
            size        INT          NOT NULL,           -- octets
            captured_at DATETIME     NOT NULL,
            INDEX idx_protocol  (protocol),
            INDEX idx_captured  (captured_at),
            INDEX idx_src_ip    (src_ip)
        ) ENGINE=InnoDB;
    """

    CREATE_TABLE_ALERTS = """
        CREATE TABLE IF NOT EXISTS alerts (
            id          INT AUTO_INCREMENT PRIMARY KEY,
            severity    ENUM('info','warning','critical') NOT NULL DEFAULT 'info',
            message     VARCHAR(255) NOT NULL,
            src_ip      VARCHAR(45),
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            resolved    BOOLEAN      NOT NULL DEFAULT FALSE
        ) ENGINE=InnoDB;
    """

    CREATE_TABLE_CAPTURES = """
        CREATE TABLE IF NOT EXISTS captures (
            id          INT AUTO_INCREMENT PRIMARY KEY,
            label       VARCHAR(64)  NOT NULL,
            started_at  DATETIME     NOT NULL,
            ended_at    DATETIME,
            total_pkts  INT          DEFAULT 0,
            total_bytes BIGINT       DEFAULT 0
        ) ENGINE=InnoDB;
    """

    def __init__(self, host="localhost", port=3306,
                 user="root", password="", database="noc_db"):
        self.config = {
            "host":     host,
            "port":     port,
            "user":     user,
            "password": password,
            "database": database,
            "autocommit": True,
            "connection_timeout": 5,
        }
        self._conn   = None          # objet de connexion MySQL
        self._cursor = None
        self.connected = False

    # ── Connexion ─────────────────────────────────────────────────────────────
    def connect(self) -> bool:
        """
        Établit la connexion MySQL.
        Retourne True si succès, False sinon.
        """
        if not MYSQL_AVAILABLE:
            return False
        try:
            self._conn   = mysql.connector.connect(**self.config)
            self._cursor = self._conn.cursor(dictionary=True)  # résultats en dict
            self.connected = True
            print(f"[DB] Connecté à {self.config['host']}:{self.config['port']}"
                  f" — base '{self.config['database']}'")
            return True
        except MySQLError as e:
            print(f"[DB] Erreur de connexion : {e}")
            self.connected = False
            return False

    def disconnect(self):
        """Ferme proprement curseur et connexion."""
        try:
            if self._cursor:
                self._cursor.close()
            if self._conn and self._conn.is_connected():
                self._conn.close()
        except Exception:
            pass
        self.connected = False
        print("[DB] Déconnecté.")

    # ── Initialisation du schéma ──────────────────────────────────────────────
    def init_database(self):
        """
        Crée la base de données et toutes les tables si elles n'existent pas.
        Appelé au premier lancement ou avec --init-db.
        """
        if not MYSQL_AVAILABLE:
            return
        # On se connecte d'abord sans spécifier la base pour la créer
        cfg_no_db = {k: v for k, v in self.config.items() if k != "database"}
        try:
            tmp = mysql.connector.connect(**cfg_no_db)
            cur = tmp.cursor()
            cur.execute(self.CREATE_DB_SQL.format(db=self.config["database"]))
            cur.close()
            tmp.close()
        except MySQLError as e:
            print(f"[DB] Impossible de créer la base : {e}")
            return

        # Puis on crée les tables
        for sql in [self.CREATE_TABLE_PACKETS,
                    self.CREATE_TABLE_ALERTS,
                    self.CREATE_TABLE_CAPTURES]:
            try:
                self._cursor.execute(sql)
            except MySQLError as e:
                print(f"[DB] Erreur création table : {e}")

        print("[DB] Schéma initialisé avec succès.")

    # ── Écriture ──────────────────────────────────────────────────────────────
    def insert_packet(self, packet: Packet) -> bool:
        """
        Insère un paquet dans la table `packets`.
        Utilise executemany en batch pour de meilleures performances
        (voir insert_packets_batch).
        """
        if not self.connected:
            return False
        sql = ("INSERT INTO packets (src_ip, dst_ip, protocol, size, captured_at) "
               "VALUES (%s, %s, %s, %s, %s)")
        try:
            self._cursor.execute(sql, packet.to_tuple())
            return True
        except MySQLError as e:
            print(f"[DB] insert_packet : {e}")
            return False

    def insert_packets_batch(self, packets: list[Packet]) -> int:
        """
        Insère une liste de paquets en une seule requête (batch).
        Retourne le nombre de lignes insérées.
        """
        if not self.connected or not packets:
            return 0
        sql = ("INSERT INTO packets (src_ip, dst_ip, protocol, size, captured_at) "
               "VALUES (%s, %s, %s, %s, %s)")
        try:
            data = [p.to_tuple() for p in packets]
            self._cursor.executemany(sql, data)
            return len(data)
        except MySQLError as e:
            print(f"[DB] insert_packets_batch : {e}")
            return 0

    def insert_alert(self, severity: str, message: str, src_ip: str = None):
        """Enregistre une alerte en base."""
        if not self.connected:
            return
        sql = ("INSERT INTO alerts (severity, message, src_ip) "
               "VALUES (%s, %s, %s)")
        try:
            self._cursor.execute(sql, (severity, message, src_ip))
        except MySQLError as e:
            print(f"[DB] insert_alert : {e}")

    # ── Lecture / Agrégation ──────────────────────────────────────────────────
    def get_stats(self) -> dict:
        """
        Retourne les KPI principaux pour la dernière heure :
          - total_packets  : nombre total de paquets
          - bandwidth_mbps : bande passante moyenne en Mbps
          - avg_latency_ms : latence simulée (calculée à partir de la taille)
          - lost_percent   : % de paquets perdus (simulé)
          - protocol_dist  : répartition par protocole {proto: count}
          - top_sources    : top 5 IP sources {ip: {count, bytes, protocol}}
          - traffic_series : [(timestamp, mbps), ...] pour le graphique de trafic
          - volume_series  : [(label, count), ...] tranches de 5 min
        """
        if not self.connected:
            return {}
        since = (datetime.now() - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
        result = {}

        # ─ Totaux ─
        try:
            self._cursor.execute(
                "SELECT COUNT(*) AS cnt, COALESCE(SUM(size),0) AS total_bytes "
                "FROM packets WHERE captured_at >= %s", (since,))
            row = self._cursor.fetchone()
            result["total_packets"] = row["cnt"] if row else 0
            total_bytes = row["total_bytes"] if row else 0
            # Mbps moyen sur 1 heure
            result["bandwidth_mbps"] = round(total_bytes * 8 / 3_600_000_000, 1)
        except MySQLError:
            result["total_packets"] = 0
            result["bandwidth_mbps"] = 0

        # ─ Latence simulée (proportionnelle à la taille moy. des paquets) ─
        try:
            self._cursor.execute(
                "SELECT AVG(size) AS avg_size FROM packets WHERE captured_at >= %s",
                (since,))
            row = self._cursor.fetchone()
            avg_size = row["avg_size"] or 500
            result["avg_latency_ms"] = round(avg_size / 200, 1)   # heuristique
        except MySQLError:
            result["avg_latency_ms"] = 0.0

        result["lost_percent"] = round(random.uniform(1.2, 2.5), 1)   # simulé

        # ─ Répartition protocoles ─
        try:
            self._cursor.execute(
                "SELECT protocol, COUNT(*) AS cnt "
                "FROM packets WHERE captured_at >= %s "
                "GROUP BY protocol ORDER BY cnt DESC", (since,))
            result["protocol_dist"] = {r["protocol"]: r["cnt"]
                                       for r in self._cursor.fetchall()}
        except MySQLError:
            result["protocol_dist"] = {}

        # ─ Top sources IP ─
        try:
            self._cursor.execute(
                "SELECT src_ip, protocol, COUNT(*) AS cnt, SUM(size) AS bytes "
                "FROM packets WHERE captured_at >= %s "
                "GROUP BY src_ip, protocol ORDER BY cnt DESC LIMIT 5", (since,))
            rows = self._cursor.fetchall()
            top = {}
            for r in rows:
                ip = r["src_ip"]
                if ip not in top:
                    top[ip] = {"count": r["cnt"],
                                "bytes": r["bytes"],
                                "protocol": r["protocol"]}
            result["top_sources"] = top
        except MySQLError:
            result["top_sources"] = {}

        # ─ Série temporelle (1 point par minute sur 60 min) ─
        try:
            self._cursor.execute("""
                SELECT DATE_FORMAT(captured_at, '%H:%i') AS minute,
                       SUM(size)*8/60000000 AS mbps
                FROM packets
                WHERE captured_at >= %s
                GROUP BY minute
                ORDER BY minute
            """, (since,))
            result["traffic_series"] = [(r["minute"], float(r["mbps"] or 0))
                                         for r in self._cursor.fetchall()]
        except MySQLError:
            result["traffic_series"] = []

        # ─ Volume par tranche de 5 min ─
        try:
            self._cursor.execute("""
                SELECT DATE_FORMAT(captured_at,
                    CONCAT('%H:', LPAD(FLOOR(MINUTE(captured_at)/5)*5, 2,'0'))
                ) AS slot,
                COUNT(*) AS cnt
                FROM packets
                WHERE captured_at >= %s
                GROUP BY slot
                ORDER BY slot
                LIMIT 12
            """, (since,))
            result["volume_series"] = [(r["slot"], r["cnt"])
                                        for r in self._cursor.fetchall()]
        except MySQLError:
            result["volume_series"] = []

        return result

    def get_active_alerts_count(self) -> int:
        """Retourne le nombre d'alertes non résolues."""
        if not self.connected:
            return 0
        try:
            self._cursor.execute(
                "SELECT COUNT(*) AS cnt FROM alerts WHERE resolved = FALSE")
            return self._cursor.fetchone()["cnt"]
        except MySQLError:
            return 0

    def ping(self) -> bool:
        """Vérifie que la connexion est toujours active."""
        try:
            if self._conn:
                self._conn.ping(reconnect=True)
                return True
        except Exception:
            pass
        return False


# ─────────────────────────────────────────────────────────────────────────────
#  SIMULATEUR RÉSEAU : NetworkSimulator
# ─────────────────────────────────────────────────────────────────────────────
class NetworkSimulator:
    """
    Génère des données réseau simulées en temps réel.
    Dans un vrai projet, cette classe lirait depuis un socket raw,
    une interface pcap (scapy/dpkt) ou un export Wireshark.

    Elle génère des paquets par lot toutes les `interval` secondes
    et les stocke dans la base de données (si connectée).
    """

    def __init__(self, db: DatabaseManager, interval: float = 1.0):
        self.db       = db
        self.interval = interval
        self._running = False
        self._thread  = None
        self._lock    = threading.Lock()

        # Buffer en mémoire (circulaire) pour les graphiques temps-réel
        self._packet_buffer: deque[Packet] = deque(maxlen=5000)
        self._stats_cache: dict = {}           # cache des dernières stats
        self._capture_num = 47                 # numéro de capture (cosmétique)

    # ── Contrôle du thread ────────────────────────────────────────────────────
    def start(self):
        """Lance le thread de simulation en arrière-plan."""
        if self._running:
            return
        self._running = True
        self._thread  = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        print("[SIM] Simulation démarrée.")

    def stop(self):
        """Arrête proprement le thread."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=3)
        print("[SIM] Simulation arrêtée.")

    def _run(self):
        """Boucle principale : génère et stocke des paquets toutes les secondes."""
        batch_size = random.randint(80, 200)   # paquets par seconde (réaliste)
        while self._running:
            packets = [Packet.random() for _ in range(batch_size)]

            # ── Injection en base de données ──────────────────────────────────
            if self.db.connected:
                self.db.insert_packets_batch(packets)
                # Détection d'anomalie simplifiée : si un IP dépasse 500 paquets/s
                src_counts = defaultdict(int)
                for p in packets:
                    src_counts[p.src_ip] += 1
                for ip, cnt in src_counts.items():
                    if cnt > 500:
                        self.db.insert_alert(
                            "warning",
                            f"Trafic anormal détecté depuis {ip} ({cnt} pkt/s)",
                            ip)

            # ── Mise à jour du buffer mémoire (pour mode sans DB) ─────────────
            with self._lock:
                self._packet_buffer.extend(packets)
                self._update_stats_from_buffer()

            batch_size = random.randint(60, 220)
            time.sleep(self.interval)

    def _update_stats_from_buffer(self):
        """
        Calcule les stats à partir du buffer en mémoire
        (utilisé quand MySQL n'est pas disponible).
        """
        packets = list(self._packet_buffer)
        if not packets:
            return

        # Totaux
        total = len(packets)
        total_bytes = sum(p.size for p in packets)

        # Répartition protocoles
        proto_dist: dict[str, int] = defaultdict(int)
        for p in packets:
            proto_dist[p.protocol] += 1

        # Top sources
        src_data: dict[str, dict] = defaultdict(lambda: {"count": 0, "bytes": 0, "protocol": "TCP"})
        for p in packets:
            src_data[p.src_ip]["count"] += 1
            src_data[p.src_ip]["bytes"] += p.size
            src_data[p.src_ip]["protocol"] = p.protocol

        top_sources = dict(sorted(src_data.items(),
                                  key=lambda x: x[1]["count"],
                                  reverse=True)[:5])

        # Série de trafic (60 derniers points = ~1 min)
        now = datetime.now()
        traffic = []
        for i in range(60):
            t = (now - timedelta(seconds=60 - i)).strftime("%H:%M")
            mbps = round(random.uniform(25, 95) + 20 * math.sin(i / 10), 1)
            traffic.append((t, mbps))

        # Volume / 5 min
        volume = []
        for i in range(12):
            slot = (now - timedelta(minutes=(11 - i) * 5)).strftime("%H:%M")
            volume.append((slot, random.randint(200, 3000)))

        self._stats_cache = {
            "total_packets":  total,
            "bandwidth_mbps": round(total_bytes * 8 / 3_600_000_000 * 60, 1),
            "avg_latency_ms": round(random.uniform(3.5, 5.5), 1),
            "lost_percent":   round(random.uniform(1.2, 2.5), 1),
            "protocol_dist":  dict(proto_dist),
            "top_sources":    top_sources,
            "traffic_series": traffic,
            "volume_series":  volume,
        }

    def get_stats(self) -> dict:
        """
        Retourne les stats depuis MySQL (si connecté) ou depuis le buffer mémoire.
        Point d'entrée unique pour l'UI.
        """
        if self.db.connected:
            stats = self.db.get_stats()
            if stats:
                return stats
        # Fallback : buffer mémoire
        with self._lock:
            return dict(self._stats_cache)

    @property
    def capture_label(self) -> str:
        return f"CAPTURE #{self._capture_num:04d}"


# ─────────────────────────────────────────────────────────────────────────────
#  WIDGETS TKINTER
# ─────────────────────────────────────────────────────────────────────────────

class KPICard(tk.Frame):
    """
    Carte de métrique clé (KPI) :
    ┌─────────────────────────┐
    │ PAQUETS TOTAUX     📦  │
    │ 18 432                  │
    │ ↑ +2.4% vs précédente   │
    └─────────────────────────┘
    Paramètres :
        parent  : widget parent
        title   : libellé en haut (ex: "PAQUETS TOTAUX")
        unit    : unité affichée après la valeur (ex: "Mbps", "%")
        delta_text : texte de comparaison (optionnel)
        delta_positive : True → vert, False → rouge
    """

    def __init__(self, parent, title: str, unit: str = "",
                 delta_text: str = "", delta_positive: bool = True, **kwargs):
        super().__init__(parent,
                         bg=COLORS["bg_card"],
                         relief="flat",
                         bd=0,
                         **kwargs)

        # ── Titre ─────────────────────────────────────────────────────────────
        tk.Label(self,
                 text=title,
                 font=("Consolas", 9, "bold"),
                 fg=COLORS["text_muted"],
                 bg=COLORS["bg_card"],
                 anchor="w").pack(anchor="w", padx=16, pady=(14, 0))

        # ── Valeur principale + unité ──────────────────────────────────────────
        value_frame = tk.Frame(self, bg=COLORS["bg_card"])
        value_frame.pack(anchor="w", padx=16, pady=(4, 0))

        self._value_label = tk.Label(value_frame,
                                      text="—",
                                      font=("Consolas", 28, "bold"),
                                      fg=COLORS["text_primary"],
                                      bg=COLORS["bg_card"])
        self._value_label.pack(side="left")

        if unit:
            tk.Label(value_frame,
                     text=f" {unit}",
                     font=("Consolas", 14),
                     fg=COLORS["text_muted"],
                     bg=COLORS["bg_card"]).pack(side="left", padx=(4, 0), pady=(8, 0))

        # ── Ligne delta ────────────────────────────────────────────────────────
        delta_color = COLORS["text_green"] if delta_positive else COLORS["text_red"]
        self._delta_label = tk.Label(self,
                                      text=delta_text,
                                      font=("Consolas", 9),
                                      fg=delta_color,
                                      bg=COLORS["bg_card"],
                                      anchor="w")
        self._delta_label.pack(anchor="w", padx=16, pady=(2, 14))

        # Bord gauche coloré (accent)
        accent = tk.Frame(self, bg=COLORS["accent_green"], width=3)
        accent.place(x=0, y=0, relheight=1)

    def update_value(self, value: str | int | float, delta_text: str = "",
                     delta_positive: bool = True):
        """Met à jour la valeur affichée et le texte delta."""
        # Formatage : ajoute des espaces tous les 3 chiffres
        if isinstance(value, (int, float)):
            formatted = f"{int(value):,}".replace(",", " ")
        else:
            formatted = str(value)

        self._value_label.config(text=formatted)
        if delta_text:
            color = COLORS["text_green"] if delta_positive else COLORS["text_red"]
            arrow = "↑" if delta_positive else "↓"
            self._delta_label.config(text=f"{arrow} {delta_text}", fg=color)


# ─────────────────────────────────────────────────────────────────────────────
class TrafficChart(tk.Frame):
    """
    Graphique linéaire du trafic réseau sur les 60 dernières minutes.
    Utilise matplotlib embarqué dans Tkinter via FigureCanvasTkAgg.
    """

    def __init__(self, parent, **kwargs):
        super().__init__(parent, bg=COLORS["bg_card"], **kwargs)

        # ── En-tête ────────────────────────────────────────────────────────────
        header = tk.Frame(self, bg=COLORS["bg_card"])
        header.pack(fill="x", padx=16, pady=(14, 0))
        tk.Label(header,
                 text="TRAFIC RÉSEAU — 60 DERNIÈRES MINUTES",
                 font=("Consolas", 9, "bold"),
                 fg=COLORS["text_muted"],
                 bg=COLORS["bg_card"]).pack(side="left")
        tk.Label(header,
                 text="Mbps",
                 font=("Consolas", 9),
                 fg=COLORS["text_muted"],
                 bg=COLORS["bg_card"]).pack(side="right")

        if not MATPLOTLIB_AVAILABLE:
            tk.Label(self, text="matplotlib requis\npip install matplotlib",
                     fg=COLORS["text_muted"], bg=COLORS["bg_card"],
                     font=("Consolas", 10)).pack(expand=True)
            return

        # ── Figure matplotlib ──────────────────────────────────────────────────
        self._fig = Figure(figsize=(9, 2.8), facecolor=COLORS["bg_chart"])
        self._ax  = self._fig.add_subplot(111)
        self._ax.set_facecolor(COLORS["bg_chart"])
        self._ax.tick_params(colors=COLORS["text_muted"], labelsize=7)
        for spine in self._ax.spines.values():
            spine.set_edgecolor(COLORS["border"])
        self._fig.subplots_adjust(left=0.04, right=0.98, top=0.92, bottom=0.18)

        # Canvas Tkinter
        canvas = FigureCanvasTkAgg(self._fig, master=self)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=8, pady=8)
        self._canvas = canvas

    def update_data(self, series: list[tuple[str, float]]):
        """
        Met à jour le graphique avec une nouvelle série de données.
        series = [(label_temps, valeur_mbps), ...]
        """
        if not MATPLOTLIB_AVAILABLE or not series:
            return
        labels = [s[0] for s in series]
        values = [s[1] for s in series]
        x = list(range(len(values)))

        self._ax.clear()
        self._ax.set_facecolor(COLORS["bg_chart"])

        # Tracé de la courbe avec remplissage
        self._ax.plot(x, values,
                      color=COLORS["accent_green"],
                      linewidth=1.8,
                      zorder=3)
        self._ax.fill_between(x, values,
                               alpha=0.15,
                               color=COLORS["accent_green"],
                               zorder=2)

        # Grille horizontale discrète
        self._ax.yaxis.grid(True, color=COLORS["border"], linewidth=0.5, alpha=0.5)
        self._ax.set_axisbelow(True)

        # Étiquettes X (toutes les N étapes pour ne pas surcharger)
        step = max(1, len(labels) // 8)
        self._ax.set_xticks(x[::step])
        self._ax.set_xticklabels(labels[::step],
                                  fontsize=7,
                                  color=COLORS["text_muted"],
                                  rotation=0)
        self._ax.tick_params(axis="y", colors=COLORS["text_muted"], labelsize=7)
        for spine in self._ax.spines.values():
            spine.set_edgecolor(COLORS["border"])

        self._canvas.draw_idle()   # rafraîchissement non bloquant


# ─────────────────────────────────────────────────────────────────────────────
class ProtocolChart(tk.Frame):
    """
    Graphique en anneau (donut) de la répartition des protocoles.
    TCP / UDP / HTTP / DNS / ARP
    """

    PROTO_COLORS = [
        COLORS["protocol_tcp"],
        COLORS["protocol_udp"],
        COLORS["protocol_http"],
        COLORS["protocol_dns"],
        COLORS["protocol_arp"],
    ]

    def __init__(self, parent, **kwargs):
        super().__init__(parent, bg=COLORS["bg_card"], **kwargs)

        tk.Label(self,
                 text="RÉPARTITION PROTOCOLES",
                 font=("Consolas", 9, "bold"),
                 fg=COLORS["text_muted"],
                 bg=COLORS["bg_card"]).pack(anchor="w", padx=16, pady=(14, 0))

        if not MATPLOTLIB_AVAILABLE:
            tk.Label(self, text="matplotlib requis",
                     fg=COLORS["text_muted"], bg=COLORS["bg_card"],
                     font=("Consolas", 10)).pack(expand=True)
            # Légende textuelle de secours
            self._legend_frame = tk.Frame(self, bg=COLORS["bg_card"])
            self._legend_frame.pack(fill="x", padx=16, pady=8)
            return

        # ── Figure ────────────────────────────────────────────────────────────
        self._fig = Figure(figsize=(3.5, 3.2), facecolor=COLORS["bg_chart"])
        self._ax  = self._fig.add_subplot(111)
        self._ax.set_facecolor(COLORS["bg_chart"])
        self._fig.subplots_adjust(left=0.02, right=0.98, top=0.95, bottom=0.02)

        canvas = FigureCanvasTkAgg(self._fig, master=self)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=8)
        self._canvas = canvas

        # ── Légende ────────────────────────────────────────────────────────────
        self._legend_frame = tk.Frame(self, bg=COLORS["bg_card"])
        self._legend_frame.pack(fill="x", padx=16, pady=(0, 12))

    def update_data(self, proto_dist: dict):
        """
        Met à jour le graphique anneau et la légende.
        proto_dist = {"TCP": 1200, "UDP": 450, ...}
        """
        if not proto_dist:
            return

        # ── Nettoyage de la légende précédente ────────────────────────────────
        for w in self._legend_frame.winfo_children():
            w.destroy()

        protos = list(proto_dist.keys())
        counts = list(proto_dist.values())
        total  = sum(counts)
        colors = self.PROTO_COLORS[:len(protos)]

        # ── Légende textuelle ─────────────────────────────────────────────────
        for i, (proto, cnt) in enumerate(proto_dist.items()):
            row = tk.Frame(self._legend_frame, bg=COLORS["bg_card"])
            row.pack(fill="x", pady=1)
            pct = round(cnt / total * 100) if total else 0
            color = colors[i] if i < len(colors) else "#ffffff"
            tk.Label(row, text="●", fg=color, bg=COLORS["bg_card"],
                     font=("Consolas", 9)).pack(side="left")
            tk.Label(row, text=f" {proto}", fg=COLORS["text_primary"],
                     bg=COLORS["bg_card"], font=("Consolas", 9),
                     width=6, anchor="w").pack(side="left")
            tk.Label(row, text=f"{pct}%", fg=COLORS["text_muted"],
                     bg=COLORS["bg_card"], font=("Consolas", 9),
                     anchor="e").pack(side="right")

        if not MATPLOTLIB_AVAILABLE:
            return

        # ── Donut matplotlib ──────────────────────────────────────────────────
        self._ax.clear()
        self._ax.set_facecolor(COLORS["bg_chart"])

        wedges, _ = self._ax.pie(
            counts,
            colors=colors,
            startangle=90,
            wedgeprops={"linewidth": 2, "edgecolor": COLORS["bg_chart"]},
            pctdistance=0.85,
        )
        # Cercle intérieur pour créer l'effet "donut"
        centre_circle = plt.Circle((0, 0), 0.62, color=COLORS["bg_chart"])
        self._ax.add_patch(centre_circle)
        self._ax.axis("equal")

        self._canvas.draw_idle()


# ─────────────────────────────────────────────────────────────────────────────
class TopSourcesTable(tk.Frame):
    """
    Tableau des 5 IP sources générant le plus de trafic.
    Colonnes : Rang · IP · Protocol · Paquets · Volume
    """

    def __init__(self, parent, **kwargs):
        super().__init__(parent, bg=COLORS["bg_card"], **kwargs)

        tk.Label(self,
                 text="TOP SOURCES IP",
                 font=("Consolas", 9, "bold"),
                 fg=COLORS["text_muted"],
                 bg=COLORS["bg_card"]).pack(anchor="w", padx=16, pady=(14, 8))

        # Conteneur des lignes
        self._rows_frame = tk.Frame(self, bg=COLORS["bg_card"])
        self._rows_frame.pack(fill="both", expand=True, padx=16, pady=(0, 14))

    def update_data(self, top_sources: dict):
        """
        Rafraîchit le tableau.
        top_sources = {"192.168.1.45": {"count": 4821, "bytes": 12_400_000, "protocol": "TCP"}}
        """
        for w in self._rows_frame.winfo_children():
            w.destroy()

        proto_colors = {
            "TCP":  COLORS["protocol_tcp"],
            "UDP":  COLORS["protocol_udp"],
            "HTTP": COLORS["protocol_http"],
            "DNS":  COLORS["protocol_dns"],
            "ARP":  COLORS["protocol_arp"],
        }

        for rank, (ip, data) in enumerate(list(top_sources.items())[:5], start=1):
            row = tk.Frame(self._rows_frame,
                           bg=COLORS["bg_card"],
                           pady=4)
            row.pack(fill="x")

            # Rang
            tk.Label(row, text=str(rank),
                     width=2, anchor="e",
                     font=("Consolas", 10),
                     fg=COLORS["text_muted"],
                     bg=COLORS["bg_card"]).pack(side="left")

            # IP
            tk.Label(row, text=f"  {ip}",
                     font=("Consolas", 11, "bold"),
                     fg=COLORS["text_primary"],
                     bg=COLORS["bg_card"],
                     width=16, anchor="w").pack(side="left")

            # Protocole (badge coloré)
            proto = data.get("protocol", "TCP")
            color = proto_colors.get(proto, COLORS["text_muted"])
            badge = tk.Label(row, text=proto,
                              font=("Consolas", 8, "bold"),
                              fg=color,
                              bg=COLORS["bg_card"],
                              relief="solid",
                              bd=1,
                              padx=4)
            badge.pack(side="left", padx=4)

            # Paquets
            tk.Label(row,
                     text=f"{data.get('count', 0):,}".replace(",", " "),
                     font=("Consolas", 10),
                     fg=COLORS["text_primary"],
                     bg=COLORS["bg_card"],
                     width=7, anchor="e").pack(side="left")

            # Volume en Mo
            mb = data.get("bytes", 0) / 1_000_000
            tk.Label(row,
                     text=f"  {mb:.1f} MB",
                     font=("Consolas", 10),
                     fg=COLORS["text_muted"],
                     bg=COLORS["bg_card"]).pack(side="left")

            # Indicateur actif (point vert)
            tk.Label(row, text="●",
                     font=("Consolas", 8),
                     fg=COLORS["text_green"],
                     bg=COLORS["bg_card"]).pack(side="right")

            # Séparateur
            tk.Frame(self._rows_frame,
                     bg=COLORS["border"],
                     height=1).pack(fill="x")


# ─────────────────────────────────────────────────────────────────────────────
class VolumeChart(tk.Frame):
    """
    Histogramme vertical du volume de paquets par tranche de 5 minutes.
    """

    def __init__(self, parent, **kwargs):
        super().__init__(parent, bg=COLORS["bg_card"], **kwargs)

        tk.Label(self,
                 text="VOLUME DE PAQUETS / 5 MIN",
                 font=("Consolas", 9, "bold"),
                 fg=COLORS["text_muted"],
                 bg=COLORS["bg_card"]).pack(anchor="w", padx=16, pady=(14, 0))

        if not MATPLOTLIB_AVAILABLE:
            tk.Label(self, text="matplotlib requis",
                     fg=COLORS["text_muted"], bg=COLORS["bg_card"],
                     font=("Consolas", 10)).pack(expand=True)
            return

        self._fig = Figure(figsize=(5, 2.8), facecolor=COLORS["bg_chart"])
        self._ax  = self._fig.add_subplot(111)
        self._ax.set_facecolor(COLORS["bg_chart"])
        self._fig.subplots_adjust(left=0.05, right=0.98, top=0.9, bottom=0.18)

        canvas = FigureCanvasTkAgg(self._fig, master=self)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=8, pady=8)
        self._canvas = canvas

    def update_data(self, volume_series: list[tuple[str, int]]):
        if not MATPLOTLIB_AVAILABLE or not volume_series:
            return

        labels = [s[0] for s in volume_series]
        counts = [s[1] for s in volume_series]
        x = list(range(len(counts)))

        self._ax.clear()
        self._ax.set_facecolor(COLORS["bg_chart"])

        # Barres avec couleur variable (haut = accent cyan)
        bar_colors = [COLORS["accent_cyan"] if c == max(counts)
                      else COLORS["accent_blue"] for c in counts]
        self._ax.bar(x, counts, color=bar_colors, width=0.65, zorder=3)
        self._ax.yaxis.grid(True, color=COLORS["border"], linewidth=0.5, alpha=0.4)
        self._ax.set_axisbelow(True)

        step = max(1, len(labels) // 6)
        self._ax.set_xticks(x[::step])
        self._ax.set_xticklabels(labels[::step],
                                  fontsize=7,
                                  color=COLORS["text_muted"],
                                  rotation=0)
        self._ax.tick_params(axis="y", colors=COLORS["text_muted"], labelsize=7)
        for spine in self._ax.spines.values():
            spine.set_edgecolor(COLORS["border"])

        self._canvas.draw_idle()


# ─────────────────────────────────────────────────────────────────────────────
class AlertBadge(tk.Frame):
    """
    Petit widget de badge d'alertes actives dans la barre de navigation.
    Clignote quand il y a des alertes critiques.
    """

    def __init__(self, parent, **kwargs):
        super().__init__(parent, bg=COLORS["bg_dark"], **kwargs)
        self._count = 0
        self._blink = False

        self._label = tk.Label(self,
                                text="Alertes (0)",
                                font=("Consolas", 10),
                                fg=COLORS["text_muted"],
                                bg=COLORS["bg_dark"],
                                cursor="hand2")
        self._label.pack()
        self._dot = tk.Label(self,
                              text="●",
                              font=("Consolas", 8),
                              fg=COLORS["text_muted"],
                              bg=COLORS["bg_dark"])
        self._dot.pack(side="right")
        self._blink_task = None

    def update_count(self, count: int):
        """Met à jour le badge et active le clignotement si > 0."""
        self._count = count
        text_color = COLORS["text_red"] if count > 0 else COLORS["text_muted"]
        self._label.config(text=f"Alertes ({count})", fg=text_color)
        if count > 0 and not self._blink:
            self._start_blink()
        elif count == 0:
            self._stop_blink()

    def _start_blink(self):
        self._blink = True
        self._do_blink(True)

    def _stop_blink(self):
        self._blink = False
        self._dot.config(fg=COLORS["text_muted"])

    def _do_blink(self, state: bool):
        if not self._blink:
            return
        color = COLORS["text_red"] if state else COLORS["bg_dark"]
        self._dot.config(fg=color)
        self._blink_task = self.after(600, lambda: self._do_blink(not state))


# ─────────────────────────────────────────────────────────────────────────────
#  FENÊTRE PRINCIPALE : NOCDashboard
# ─────────────────────────────────────────────────────────────────────────────
class NOCDashboard(tk.Tk):
    """
    Fenêtre principale du tableau de bord NOC.
    Hérite de tk.Tk — c'est la racine de l'application.

    Responsabilités :
      1. Construire l'interface (barre de nav + grille de widgets)
      2. Instancier DatabaseManager et NetworkSimulator
      3. Lancer la boucle de rafraîchissement périodique (toutes les 2 s)
      4. Distribuer les données aux widgets via leurs méthodes update_*
    """

    REFRESH_INTERVAL_MS = 2000   # intervalle de rafraîchissement (ms)
    WINDOW_TITLE        = "NetSupervision — NOC Dashboard"

    def __init__(self, db_config: dict | None = None):
        super().__init__()

        # ── Configuration de la fenêtre ───────────────────────────────────────
        self.title(self.WINDOW_TITLE)
        self.configure(bg=COLORS["bg_dark"])
        self.geometry("1400x860")
        self.minsize(1100, 700)

        # Icône de la fenêtre (optionnel)
        # self.iconbitmap("icon.ico")

        # ── Couche données ────────────────────────────────────────────────────
        cfg = db_config or {}
        self._db  = DatabaseManager(
            host=cfg.get("host",     "localhost"),
            port=cfg.get("port",     3306),
            user=cfg.get("user",     "root"),
            password=cfg.get("password", ""),
            database=cfg.get("database", "noc_db"),
        )
        self._sim = NetworkSimulator(db=self._db, interval=1.0)

        # Tentative de connexion MySQL (non bloquante)
        self._db_status = "disconnected"
        threading.Thread(target=self._try_connect_db, daemon=True).start()

        # ── Construction de l'interface ───────────────────────────────────────
        self._build_navbar()
        self._build_kpi_row()
        self._build_charts_row()
        self._build_bottom_row()
        self._build_statusbar()

        # ── Démarrage de la simulation et du rafraîchissement ─────────────────
        self._sim.start()
        self._schedule_refresh()

        # ── Gestion de la fermeture ───────────────────────────────────────────
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ── Connexion DB (thread séparé pour ne pas bloquer l'UI) ─────────────────
    def _try_connect_db(self):
        """Essaie de se connecter à MySQL en arrière-plan."""
        if self._db.connect():
            self._db.init_database()
            self._db_status = "connected"
        else:
            self._db_status = "disconnected"

    # =========================================================================
    #  CONSTRUCTION DE L'INTERFACE
    # =========================================================================

    def _build_navbar(self):
        """
        Barre de navigation supérieure :
        Logo | NetSupervision / NOC Dashboard | Onglets | Heure | Rafraîchir
        """
        nav = tk.Frame(self, bg=COLORS["bg_card"], height=48)
        nav.pack(fill="x", side="top")
        nav.pack_propagate(False)

        # Logo (symbole réseau)
        tk.Label(nav, text="⬡",
                 font=("Consolas", 18),
                 fg=COLORS["accent_cyan"],
                 bg=COLORS["bg_card"]).pack(side="left", padx=(12, 0))

        # Fil d'Ariane
        tk.Label(nav, text="NetSupervision",
                 font=("Consolas", 11, "bold"),
                 fg=COLORS["text_primary"],
                 bg=COLORS["bg_card"]).pack(side="left", padx=(8, 0))
        tk.Label(nav, text=" / NOC Dashboard",
                 font=("Consolas", 11),
                 fg=COLORS["text_muted"],
                 bg=COLORS["bg_card"]).pack(side="left")

        # Séparateur vertical
        tk.Frame(nav, bg=COLORS["border"], width=1).pack(
            side="left", fill="y", padx=20)

        # Onglets (simulés — non fonctionnels dans ce démo)
        tabs = ["Tableau de bord", "Paquets", "Base de données"]
        for i, tab in enumerate(tabs):
            is_active = (i == 0)
            color  = COLORS["accent_cyan"]  if is_active else COLORS["text_muted"]
            border = COLORS["accent_cyan"]  if is_active else COLORS["bg_card"]
            btn = tk.Label(nav, text=tab,
                           font=("Consolas", 10, "bold" if is_active else "normal"),
                           fg=color,
                           bg=COLORS["bg_card"],
                           padx=12, pady=4,
                           cursor="hand2",
                           relief="flat",
                           bd=0)
            btn.pack(side="left")
            if is_active:
                tk.Frame(nav, bg=COLORS["accent_cyan"], height=2).place(
                    in_=btn, relx=0, rely=1, relwidth=1, anchor="sw")

        # ── Droite : badge alerte + heure + rafraîchir ────────────────────────
        # Bouton Rafraîchir
        tk.Button(nav, text="⟳",
                  font=("Consolas", 14),
                  fg=COLORS["text_muted"],
                  bg=COLORS["bg_card"],
                  activebackground=COLORS["bg_card"],
                  relief="flat", bd=0,
                  cursor="hand2",
                  command=self._force_refresh).pack(side="right", padx=12)

        # Horloge
        self._clock_label = tk.Label(nav, text="",
                                      font=("Consolas", 10),
                                      fg=COLORS["text_primary"],
                                      bg=COLORS["bg_card"])
        self._clock_label.pack(side="right", padx=8)
        self._update_clock()

        # Badge capture
        self._capture_label_var = tk.StringVar(value="CAPTURE #0047")
        tk.Label(nav,
                 textvariable=self._capture_label_var,
                 font=("Consolas", 9),
                 fg=COLORS["text_muted"],
                 bg=COLORS["bg_card"]).pack(side="right", padx=8)

        # Point vert "live"
        tk.Label(nav, text="●",
                 font=("Consolas", 8),
                 fg=COLORS["text_green"],
                 bg=COLORS["bg_card"]).pack(side="right")

        # Badge alertes
        self._alert_badge = AlertBadge(nav)
        self._alert_badge.pack(side="right", padx=16)

    def _build_kpi_row(self):
        """
        Rangée de 4 KPICards :
        Paquets totaux | Bande passante | Latence moy. | Paquets perdus
        """
        row = tk.Frame(self, bg=COLORS["bg_dark"])
        row.pack(fill="x", padx=12, pady=(12, 0))

        # Chaque carte prend 25% de la largeur
        for col in range(4):
            row.columnconfigure(col, weight=1, uniform="kpi")

        # ── Carte 1 : Paquets totaux ──────────────────────────────────────────
        self._card_packets = KPICard(row,
                                      title="PAQUETS TOTAUX",
                                      unit="",
                                      delta_text="+2.4% vs capture précédente",
                                      delta_positive=True)
        self._card_packets.grid(row=0, column=0, sticky="nsew", padx=(0, 6))

        # ── Carte 2 : Bande passante ──────────────────────────────────────────
        self._card_bw = KPICard(row,
                                 title="BANDE PASSANTE",
                                 unit="Mbps",
                                 delta_text="+17%",
                                 delta_positive=True)
        self._card_bw.grid(row=0, column=1, sticky="nsew", padx=3)

        # ── Carte 3 : Latence moyenne ─────────────────────────────────────────
        self._card_latency = KPICard(row,
                                      title="LATENCE MOYENNE",
                                      unit="ms",
                                      delta_text="-0.3ms",
                                      delta_positive=True)   # baisse = bon
        self._card_latency.grid(row=0, column=2, sticky="nsew", padx=3)

        # ── Carte 4 : Paquets perdus ──────────────────────────────────────────
        self._card_lost = KPICard(row,
                                   title="PAQUETS PERDUS",
                                   unit="%",
                                   delta_text="+0.4% retransmissions TCP",
                                   delta_positive=False)   # hausse = mauvais
        self._card_lost.grid(row=0, column=3, sticky="nsew", padx=(6, 0))

    def _build_charts_row(self):
        """
        Rangée principale : graphique de trafic (gauche 65%) + donut protocoles (droite 35%)
        """
        row = tk.Frame(self, bg=COLORS["bg_dark"])
        row.pack(fill="both", expand=True, padx=12, pady=(12, 0))
        row.columnconfigure(0, weight=65)
        row.columnconfigure(1, weight=35)

        self._traffic_chart = TrafficChart(row)
        self._traffic_chart.grid(row=0, column=0, sticky="nsew", padx=(0, 6))

        self._protocol_chart = ProtocolChart(row)
        self._protocol_chart.grid(row=0, column=1, sticky="nsew", padx=(6, 0))

    def _build_bottom_row(self):
        """
        Rangée du bas : tableau Top IP (gauche 45%) + histogramme volume (droite 55%)
        """
        row = tk.Frame(self, bg=COLORS["bg_dark"])
        row.pack(fill="both", expand=True, padx=12, pady=(12, 0))
        row.columnconfigure(0, weight=45)
        row.columnconfigure(1, weight=55)

        self._top_sources = TopSourcesTable(row)
        self._top_sources.grid(row=0, column=0, sticky="nsew", padx=(0, 6))

        self._volume_chart = VolumeChart(row)
        self._volume_chart.grid(row=0, column=1, sticky="nsew", padx=(6, 0))

    def _build_statusbar(self):
        """
        Barre de statut en bas :
        ● Collecte active | SQLite / MySQL | ○ N menaces détectées | Wireshark export …
        """
        bar = tk.Frame(self, bg=COLORS["bg_card"], height=28)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)

        # ── Gauche ────────────────────────────────────────────────────────────
        tk.Label(bar, text="● Collecte active",
                 font=("Consolas", 8),
                 fg=COLORS["text_green"],
                 bg=COLORS["bg_card"]).pack(side="left", padx=12)

        tk.Frame(bar, bg=COLORS["border"], width=1).pack(
            side="left", fill="y", pady=6)

        # Statut base de données
        self._db_status_label = tk.Label(bar,
                                          text="⬡ SQLite · 284 MB",
                                          font=("Consolas", 8),
                                          fg=COLORS["text_muted"],
                                          bg=COLORS["bg_card"])
        self._db_status_label.pack(side="left", padx=12)

        tk.Frame(bar, bg=COLORS["border"], width=1).pack(
            side="left", fill="y", pady=6)

        # Menaces
        self._threat_label = tk.Label(bar,
                                       text="○ 1 menace détectée",
                                       font=("Consolas", 8),
                                       fg=COLORS["text_orange"],
                                       bg=COLORS["bg_card"])
        self._threat_label.pack(side="left", padx=12)

        # ── Droite ────────────────────────────────────────────────────────────
        self._export_label = tk.Label(bar,
                                       text="Wireshark export #0047 · 18 432 paquets · 14:35 – 14:52",
                                       font=("Consolas", 8),
                                       fg=COLORS["text_muted"],
                                       bg=COLORS["bg_card"])
        self._export_label.pack(side="right", padx=12)

    # =========================================================================
    #  RAFRAÎCHISSEMENT PÉRIODIQUE
    # =========================================================================

    def _schedule_refresh(self):
        """Planifie le prochain rafraîchissement avec after() (thread-safe)."""
        self._refresh()
        self.after(self.REFRESH_INTERVAL_MS, self._schedule_refresh)

    def _force_refresh(self):
        """Rafraîchissement immédiat déclenché par le bouton ⟳."""
        self._refresh()

    def _refresh(self):
        """
        Point central de mise à jour :
        1. Récupère les stats (DB ou buffer mémoire)
        2. Distribue les données à chaque widget
        3. Met à jour la barre de statut
        """
        stats = self._sim.get_stats()
        if not stats:
            return   # données pas encore prêtes

        # ── KPI Cards ─────────────────────────────────────────────────────────
        self._card_packets.update_value(
            stats.get("total_packets", 0),
            "+2.4% vs capture précédente", True)

        bw = stats.get("bandwidth_mbps", 0)
        self._card_bw.update_value(bw, "+17%", True)

        lat = stats.get("avg_latency_ms", 0)
        self._card_latency.update_value(f"{lat}", "-0.3ms", True)

        lost = stats.get("lost_percent", 0)
        self._card_lost.update_value(f"{lost}", "+0.4% retransmissions TCP", False)

        # ── Graphiques ────────────────────────────────────────────────────────
        traffic = stats.get("traffic_series", [])
        if traffic:
            self._traffic_chart.update_data(traffic)

        protos = stats.get("protocol_dist", {})
        if protos:
            self._protocol_chart.update_data(protos)

        # ── Tableau Top Sources ────────────────────────────────────────────────
        top = stats.get("top_sources", {})
        if top:
            self._top_sources.update_data(top)

        # ── Histogramme volume ────────────────────────────────────────────────
        volume = stats.get("volume_series", [])
        if volume:
            self._volume_chart.update_data(volume)

        # ── Barre de statut ───────────────────────────────────────────────────
        self._update_statusbar(stats)

        # ── Badge alertes ─────────────────────────────────────────────────────
        alert_count = self._db.get_active_alerts_count() if self._db.connected else 0
        self._alert_badge.update_count(alert_count)

    def _update_statusbar(self, stats: dict):
        """Met à jour les labels de la barre de statut."""
        # Connexion DB
        if self._db.connected:
            self._db_status_label.config(
                text="⬡ MySQL · Connecté",
                fg=COLORS["text_green"])
        else:
            self._db_status_label.config(
                text="⬡ Mode démo (sans DB)",
                fg=COLORS["text_orange"])

        # Export
        total = stats.get("total_packets", 0)
        now   = datetime.now().strftime("%H:%M")
        self._export_label.config(
            text=f"Capture active · {total:,} paquets · {now}".replace(",", " "))

    def _update_clock(self):
        """Met à jour l'horloge en temps réel (toutes les secondes)."""
        self._clock_label.config(text=datetime.now().strftime("%H:%M:%S"))
        self.after(1000, self._update_clock)

    # =========================================================================
    #  FERMETURE
    # =========================================================================

    def _on_close(self):
        """Arrêt propre : simulation → déconnexion DB → fermeture fenêtre."""
        self._sim.stop()
        self._db.disconnect()
        self.destroy()


# ─────────────────────────────────────────────────────────────────────────────
#  POINT D'ENTRÉE
# ─────────────────────────────────────────────────────────────────────────────
def parse_args():
    """Analyse les arguments en ligne de commande."""
    parser = argparse.ArgumentParser(
        description="NetSupervision NOC Dashboard")
    parser.add_argument("--host",     default="localhost",
                        help="Hôte MySQL (défaut: localhost)")
    parser.add_argument("--port",     type=int, default=3306,
                        help="Port MySQL (défaut: 3306)")
    parser.add_argument("--user",     default="root",
                        help="Utilisateur MySQL (défaut: root)")
    parser.add_argument("--password", default="",
                        help="Mot de passe MySQL")
    parser.add_argument("--database", default="noc_db",
                        help="Nom de la base de données (défaut: noc_db)")
    parser.add_argument("--init-db",  action="store_true",
                        help="Initialise le schéma MySQL et quitte")
    return parser.parse_args()


def main():
    args = parse_args()

    db_config = {
        "host":     args.host,
        "port":     args.port,
        "user":     args.user,
        "password": args.password,
        "database": args.database,
    }

    # Mode --init-db : crée la base et les tables, puis quitte
    if args.init_db:
        if not MYSQL_AVAILABLE:
            print("ERREUR : mysql-connector-python n'est pas installé.")
            print("  → pip install mysql-connector-python")
            sys.exit(1)
        print("=== Initialisation de la base de données ===")
        db = DatabaseManager(**db_config)
        if db.connect():
            db.init_database()
            db.disconnect()
            print("✓ Schéma créé avec succès.")
        else:
            print("✗ Impossible de se connecter à MySQL.")
            print("  Vérifiez vos identifiants (--user, --password, --host).")
        sys.exit(0)

    # Lancement de l'application graphique
    app = NOCDashboard(db_config=db_config)
    app.mainloop()


if __name__ == "__main__":
    main()
