-- =============================================================================
--  NetSupervision — NOC Dashboard
--  Script de création de la base de données
--  Compatible : MySQL 5.7+ / MySQL 8.0+ / MySQL Workbench
--
--  UTILISATION :
--    1. Ouvrir MySQL Workbench
--    2. File → Open SQL Script → choisir ce fichier
--    3. Cliquer sur l'éclair ⚡ (Execute All) ou Ctrl+Shift+Enter
-- =============================================================================


-- -----------------------------------------------------------------------------
-- 1. CRÉATION DE LA BASE DE DONNÉES
-- -----------------------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS noc_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

-- On se place dans la base
USE noc_db;


-- -----------------------------------------------------------------------------
-- 2. TABLE : packets
--    Stocke chaque paquet réseau capturé
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS packets (
    id          INT             AUTO_INCREMENT PRIMARY KEY,
    src_ip      VARCHAR(45)     NOT NULL COMMENT 'IP source (IPv4 ou IPv6)',
    dst_ip      VARCHAR(45)     NOT NULL COMMENT 'IP destination',
    protocol    VARCHAR(10)     NOT NULL COMMENT 'TCP / UDP / HTTP / DNS / ARP',
    size        INT             NOT NULL COMMENT 'Taille du paquet en octets',
    captured_at DATETIME        NOT NULL COMMENT 'Horodatage de la capture',

    INDEX idx_protocol  (protocol),
    INDEX idx_captured  (captured_at),
    INDEX idx_src_ip    (src_ip)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COMMENT='Paquets réseau capturés en temps réel';


-- -----------------------------------------------------------------------------
-- 3. TABLE : alerts
--    Stocke les alertes générées par le moteur de détection
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS alerts (
    id          INT             AUTO_INCREMENT PRIMARY KEY,
    severity    ENUM('info', 'warning', 'critical')
                                NOT NULL DEFAULT 'info'
                                COMMENT 'Niveau de sévérité',
    message     VARCHAR(255)    NOT NULL COMMENT 'Description de l alerte',
    src_ip      VARCHAR(45)     NULL     COMMENT 'IP source concernée (optionnel)',
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resolved    BOOLEAN         NOT NULL DEFAULT FALSE
                                COMMENT '0 = active, 1 = résolue',

    INDEX idx_severity  (severity),
    INDEX idx_resolved  (resolved),
    INDEX idx_created   (created_at)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COMMENT='Alertes réseau détectées';


-- -----------------------------------------------------------------------------
-- 4. TABLE : captures
--    Enregistre les sessions de capture (métadonnées)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS captures (
    id          INT             AUTO_INCREMENT PRIMARY KEY,
    label       VARCHAR(64)     NOT NULL COMMENT 'Ex: CAPTURE #0047',
    started_at  DATETIME        NOT NULL COMMENT 'Début de la capture',
    ended_at    DATETIME        NULL     COMMENT 'Fin (NULL si en cours)',
    total_pkts  INT             DEFAULT 0 COMMENT 'Nombre total de paquets',
    total_bytes BIGINT          DEFAULT 0 COMMENT 'Volume total en octets',

    INDEX idx_started (started_at)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COMMENT='Sessions de capture réseau';


-- -----------------------------------------------------------------------------
-- 5. TABLE : top_sources
--    Vue agrégée mise à jour périodiquement (optionnel — pour performances)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS top_sources_cache (
    id              INT         AUTO_INCREMENT PRIMARY KEY,
    src_ip          VARCHAR(45) NOT NULL,
    protocol        VARCHAR(10) NOT NULL,
    packet_count    INT         DEFAULT 0,
    total_bytes     BIGINT      DEFAULT 0,
    last_seen       DATETIME    NOT NULL,
    updated_at      DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP
                                ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uq_ip_proto (src_ip, protocol)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COMMENT='Cache des top sources IP (mis à jour par le dashboard)';


-- =============================================================================
-- 6. DONNÉES DE TEST (optionnel — décommenter pour tester l'affichage)
-- =============================================================================

-- -- Quelques paquets de démonstration
-- INSERT INTO packets (src_ip, dst_ip, protocol, size, captured_at) VALUES
--   ('192.168.1.45',  '10.0.0.1',   'TCP',  1024, NOW() - INTERVAL 5 MINUTE),
--   ('192.168.1.45',  '10.0.0.2',   'TCP',   512, NOW() - INTERVAL 4 MINUTE),
--   ('10.0.0.112',    '10.0.0.1',   'HTTP', 2048, NOW() - INTERVAL 3 MINUTE),
--   ('172.16.0.10',   '10.0.0.5',   'UDP',   256, NOW() - INTERVAL 2 MINUTE),
--   ('192.168.1.200', '10.0.0.1',   'DNS',    64, NOW() - INTERVAL 1 MINUTE),
--   ('10.0.0.55',     '172.16.0.1', 'ARP',    42, NOW());
--
-- -- Une alerte de test
-- INSERT INTO alerts (severity, message, src_ip) VALUES
--   ('warning', 'Trafic anormal détecté : 520 pkt/s', '192.168.1.45'),
--   ('info',    'Nouvelle session de capture démarrée', NULL);
--
-- -- Une session de capture de test
-- INSERT INTO captures (label, started_at, total_pkts, total_bytes) VALUES
--   ('CAPTURE #0047', NOW() - INTERVAL 1 HOUR, 18432, 22548000);


-- =============================================================================
-- 7. VUES UTILES (pour explorer les données dans Workbench)
-- =============================================================================

-- Vue : statistiques par protocole (dernière heure)
CREATE OR REPLACE VIEW v_protocol_stats AS
SELECT
    protocol,
    COUNT(*)        AS total_packets,
    SUM(size)       AS total_bytes,
    AVG(size)       AS avg_size,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 1) AS pct
FROM packets
WHERE captured_at >= NOW() - INTERVAL 1 HOUR
GROUP BY protocol
ORDER BY total_packets DESC;


-- Vue : top 10 sources IP (dernière heure)
CREATE OR REPLACE VIEW v_top_sources AS
SELECT
    src_ip,
    protocol,
    COUNT(*)            AS packet_count,
    SUM(size)           AS total_bytes,
    ROUND(SUM(size)/1048576, 2) AS total_mb,
    MAX(captured_at)    AS last_seen
FROM packets
WHERE captured_at >= NOW() - INTERVAL 1 HOUR
GROUP BY src_ip, protocol
ORDER BY packet_count DESC
LIMIT 10;


-- Vue : trafic par minute (dernière heure)
CREATE OR REPLACE VIEW v_traffic_per_minute AS
SELECT
    DATE_FORMAT(captured_at, '%H:%i')   AS minute,
    COUNT(*)                             AS packet_count,
    SUM(size)                            AS total_bytes,
    ROUND(SUM(size) * 8 / 60000000, 2)  AS mbps
FROM packets
WHERE captured_at >= NOW() - INTERVAL 1 HOUR
GROUP BY minute
ORDER BY minute;


-- Vue : alertes actives
CREATE OR REPLACE VIEW v_active_alerts AS
SELECT
    id,
    severity,
    message,
    src_ip,
    created_at,
    TIMESTAMPDIFF(MINUTE, created_at, NOW()) AS age_minutes
FROM alerts
WHERE resolved = FALSE
ORDER BY
    FIELD(severity, 'critical', 'warning', 'info'),
    created_at DESC;


-- =============================================================================
-- 8. VÉRIFICATION FINALE
-- =============================================================================
SELECT 'Base de données noc_db créée avec succès !' AS statut;
SHOW TABLES;
